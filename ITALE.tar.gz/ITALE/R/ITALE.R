# Must specify either lamb.seq or {lamb.init, gamma, cut.max, max.it}
ITALE.helper <- function(y,A,edges,FFT=FALSE,N1=NA,N2=NA,CV=TRUE,eta=NA,
        lamb.seq=NA,lamb.init=NA,gamma=NA,cut.max=NA,max.it=NA,cgrid.length=300,
        verbose=TRUE) {
  if (!FFT) {
    n = nrow(A)
    p = ncol(A)
  } else {
    # If FFT, then A is an n x 3 matrix, where the first two columns are the
    # coordinates (i,j) for the row of the Fourier matrix F, and the last is the
    # weight w multiplying this row. The sample y is assumed to be a noisy
    # observation of F[i,j]*w*x, where F is the *normalized* Fourier matrix
    # with row norm 1, and x is the true image.
    n = length(y)
    p = N1*N2
    mask = matrix(0,N1,N2)
    y.mat = matrix(0,N1,N2)
    for (i in 1:nrow(A)) {
      mask[A[i,1],A[i,2]] = mask[A[i,1],A[i,2]]+A[i,3]^2
      y.mat[A[i,1],A[i,2]] = y.mat[A[i,1],A[i,2]]+A[i,3]*y[i]
    }
  }
  lamb.hist = numeric(0)
  x.hist = matrix(0,0,p)
  x = rep(0,p)
  if (is.na(eta)) {
    if (!FFT) { eta = 1/max(colSums(A^2)) }
    else { eta = 1/n }
  }
  if (!is.na(lamb.seq)) { max.it = length(lamb.seq) }
  for (iter in 1:max.it) {
    if (!FFT) {
      a = x-eta*t(A)%*%(A%*%x-y)
    } else {
      x.mat = matrix(x,N1,N2)
      Ax.minus.y = fft(x.mat)/sqrt(p)*mask-y.mat
      a = Re(x-eta*as.vector(fft(Ax.minus.y, inverse=TRUE)/sqrt(p)))
    }
    cgrid = seq(min(a),max(a),length.out=cgrid.length)
    if (is.na(lamb.seq)) {
      if (iter == 1) { lamb = lamb.init }
      else { lamb = gamma*lamb }
    } else {
      lamb = lamb.seq[iter] 
    }
    out = graph_segment(a,x,cgrid,edges,lamb,30,verbose=FALSE)
    x = out$est
    cut = out$cut
    x.hist = rbind(x.hist,x)
    lamb.hist = c(lamb.hist,lamb)
    if (verbose) {
      cat(sprintf('Iteration %d, lambda = %f, gradient sparsity = %d\n',
                  iter, lamb, cut))
    }
    if (is.na(lamb.seq) && cut >= cut.max) {
      if (verbose) { cat('Gradient sparsity bound reached\n') }
      break
    } else if (is.na(lamb.seq) && iter == max.it && verbose) {
      cat('Maximum iteration reached\n')
    }
  }
  if (CV) {
    if (verbose) { cat('Running 5-fold cross-validation\n') }
    old.seed = .Random.seed
    set.seed(123)
    perm = sample(n)
    .Random.seed <<- old.seed
    folds = cut(seq(1,n),breaks=5,labels=FALSE)
    CV.error = matrix(0,length(lamb.hist),5)
    for (i in 1:5) {
      if (verbose) { cat(sprintf('Fold %d\n',i)) }
      y.test = y[perm[which(folds == i,arr.ind=TRUE)]]
      A.test = A[perm[which(folds == i,arr.ind=TRUE)],]
      y.train = y[perm[which(folds != i,arr.ind=TRUE)]]
      A.train = A[perm[which(folds != i,arr.ind=TRUE)],]
      out = ITALE.helper(y.train,A.train,edges,FFT=FFT,N1=N1,N2=N2,eta=1.25*eta,
              CV=FALSE,lamb.seq=lamb.hist,
              cgrid.length=cgrid.length,verbose=verbose)
      for (iter in 1:length(lamb.hist)) {
        if (!FFT) {
          CV.error[iter,i] = sum((y.test-A.test%*%out$est[iter,])^2)
        } else {
          x.mat = matrix(out$est[iter,],N1,N2)
          x.mat.fft = fft(x.mat)/sqrt(p)
          error = 0
          for (j in 1:nrow(A.test)) {
            error = error + (Mod(x.mat.fft[A.test[j,1],A.test[j,2]]*A.test[j,3]
                    -y.test[j]))^2
          }
          CV.error[iter,i] = error
        }
      }
    }
    CV.ind = which.min(rowSums(CV.error))
  } else {
    CV.ind = NA
  }
  return(list(est=x.hist,lamb=lamb.hist,CV.ind=CV.ind))
}

edges.1D <- function(N1) {
  edges = matrix(0,N1-1,2)
  edges[,1] = seq(0,N1-2)
  edges[,2] = seq(1,N1-1)
  return(edges)
}

edges.2D <- function(N1,N2) {
  v = function(i,j) { j*N1+i }
  edges = matrix(0,(N1-1)*N2+(N2-1)*N1,2)
  ind = 1
  for (i in 0:(N1-2)) {
    for (j in 0:(N2-2)) {
      edges[ind,] = c(v(i,j),v(i+1,j))
      ind = ind + 1
      edges[ind,] = c(v(i,j),v(i,j+1))
      ind = ind + 1
    }
  }
  for (i in 0:(N1-2)) {
    edges[ind,] = c(v(i,N2-1),v(i+1,N2-1))
    ind = ind + 1
  }
  for (j in 0:(N2-2)) {
    edges[ind,] = c(v(N1-1,j),v(N1-1,j+1))
    ind = ind + 1
  }
  return(edges)
}

ITALE.1D <- function(y,A,CV=TRUE,eta=NA,lamb.init=NA,gamma=0.9,cut.max=NA,
        max.it=200,cgrid.length=300,verbose=TRUE) {
  n = nrow(A)
  p = ncol(A)
  edges = edges.1D(p)
  if (is.na(lamb.init)) {
    a = t(A)%*%y/max(colSums(A^2))
    lamb.init = max((a-mean(a))^2)
  }
  if (is.na(cut.max)) { cut.max = 0.5*nrow(edges) }
  return(ITALE.helper(y,A,edges,FFT=FALSE,CV=CV,eta=eta,lamb.seq=NA,
              lamb.init=lamb.init,gamma=gamma,cut.max=cut.max,max.it=max.it,
              cgrid.length=cgrid.length,verbose=TRUE))
}

ITALE.2D <- function(y,A,CV=TRUE,eta=NA,lamb.init=NA,gamma=0.9,cut.max=NA,
        max.it=200,cgrid.length=300,verbose=TRUE) {
  n = dim(A)[1]
  N1 = dim(A)[2]
  N2 = dim(A)[3]
  edges = edges.2D(N1,N2)
  A.flat = matrix(A,n,N1*N2)
  if (is.na(lamb.init)) {
    a = t(A.flat)%*%y/max(colSums(A^2))
    lamb.init = max((a-mean(a))^2)
  }
  if (is.na(cut.max)) { cut.max = 0.5*nrow(edges) }
  out = ITALE.helper(y,A.flat,edges,FFT=FALSE,CV=CV,eta=eta,lamb.seq=NA,
          lamb.init=lamb.init,gamma=gamma,cut.max=cut.max,max.it=max.it,
          cgrid.length=cgrid.length,verbose=TRUE)
  dim(out$est) = c(nrow(out$est),N1,N2)
  return(out)
}

ITALE.graph <- function(y,A,edges,CV=TRUE,eta=NA,lamb.init=NA,gamma=0.9,
        cut.max=NA,max.it=200,cgrid.length=300,verbose=TRUE) {
  if (is.na(lamb.init)) {
    n = nrow(A)
    a = t(A)%*%y/max(colSums(A^2))
    lamb.init = max((a-mean(a))^2)
  }
  if (is.na(cut.max)) { cut.max = 0.5*nrow(edges) }
  return(ITALE.helper(y,A,edges,FFT=FALSE,CV=CV,eta=eta,lamb.seq=NA,
              lamb.init=lamb.init,gamma=gamma,cut.max=cut.max,max.it=max.it,
              cgrid.length=cgrid.length,verbose=TRUE))
}

ITALE.2D.FFT <- function(y,N1,N2,A,CV=TRUE,eta=NA,lamb.init=NA,gamma=0.9,
        cut.max=NA,max.it=200,cgrid.length=300,verbose=TRUE) {
  n = length(y)
  edges = edges.2D(N1,N2)
  if (is.na(lamb.init)) {
    y.mat = matrix(0,N1,N2)
    for (i in 1:nrow(A)) {
      y.mat[A[i,1],A[i,2]] = y.mat[A[i,1],A[i,2]]+A[i,3]*y[i]
    }
    a = Re(as.vector(fft(y.mat,inverse=TRUE)/sqrt(N1*N2))/n)
    lamb.init = max((a-mean(a))^2)
  }
  if (is.na(cut.max)) { cut.max = 0.5*nrow(edges) }
  out = ITALE.helper(y,A,edges,FFT=TRUE,N1=N1,N2=N2,CV=CV,eta=eta,lamb.seq=NA,
          lamb.init=lamb.init,gamma=gamma,cut.max=cut.max,max.it=max.it,
          cgrid.length=cgrid.length,verbose=TRUE)
  dim(out$est) = c(nrow(out$est),N1,N2)
  return(out)
}

