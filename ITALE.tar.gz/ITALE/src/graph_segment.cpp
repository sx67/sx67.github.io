#include "graph.h"
#include <Rcpp.h>
#include <limits>
#include <iostream>
#include <sstream>

using namespace Rcpp;

const double INF = std::numeric_limits<double>::infinity();

inline double vpen(double x, double y) {
    return (x-y)*(x-y);
}

void construct_graph(const NumericVector& a, const NumericVector& x,
        const NumericMatrix& edges, double lambda,
        double mu, Graph<double, double, double>& g) {
    g.reset();
    g.add_node(a.size());
    for (int i = 0; i < a.size(); ++i) {
        if (x[i] == mu)
            g.add_tweights(i, vpen(mu,a[i]), INF);
        else
            g.add_tweights(i, vpen(mu,a[i]), vpen(x[i],a[i]));
    }
    for (int i = 0; i < edges.nrow(); ++i) {
        if (x[edges(i,0)] == x[edges(i,1)]) {
            if (x[edges(i,0)] == mu)
                g.add_edge(edges(i,0), edges(i,1), 0, 0);
            else
                g.add_edge(edges(i,0), edges(i,1), lambda, lambda);
        }
        else {
            int newnode = g.add_node();
            g.add_tweights(newnode, 0, lambda);
            if (x[edges(i,0)] == mu)
                g.add_edge(edges(i,0), newnode, 0, 0);
            else
                g.add_edge(edges(i,0), newnode, lambda, lambda);
            if (x[edges(i,1)] == mu)
                g.add_edge(edges(i,1), newnode, 0, 0);
            else
                g.add_edge(edges(i,1), newnode, lambda, lambda);
        }
    }
}

// [[Rcpp::export]]
List graph_segment(const NumericVector& a, const NumericVector& x,
        const NumericVector& c, const NumericMatrix& edges, double lambda,
        int max_iters=100, double tau=1e-6, bool verbose=true) {
    // Check inputs
    if (a.size() != x.size()) {
        std::stringstream ss;
        ss << "ERROR: Incompatible lengths of x and a";
        ::Rf_error(ss.str().c_str());
    }
    for (int i = 0; i < edges.nrow(); ++i) {
        if (edges(i,0) < 0 || edges(i,0) >= x.size()) {
            std::stringstream ss;
            ss << "ERROR: Invalid index " << edges(i,0) << " in edges";
            ::Rf_error(ss.str().c_str());
        }
        if (edges(i,1) < 0 || edges(i,1) >= x.size()) {
            std::stringstream ss;
            ss << "ERROR: Invalid index " << edges(i,1) << " in edges";
            ::Rf_error(ss.str().c_str());
        }
    }
    Graph<double, double, double> g(a.size()+edges.size(),2*edges.size());
    // Initialize by x, and initialize prev_flow to objective value at x
    NumericVector xout(clone(x));
    double prev_flow = 0;
    for (int i = 0; i < xout.size(); ++i) {
        prev_flow += vpen(xout[i],a[i]);
    }
    for (int i = 0; i < edges.nrow(); ++i) {
        if (xout[edges(i,0)] != xout[edges(i,1)]) {
            prev_flow += lambda;
        }
    }
    int iter = 1;
    for (; iter <= max_iters; ++iter) {
        if (verbose)
            std::cout << "Iteration " << iter << std::endl;
        bool changed = false;
        for (int i = 0; i < c.size(); ++i) {
            //if (verbose)
            //    std::cout << "... " << c[i] << std::endl;
            construct_graph(a,xout,edges,lambda,c[i],g);
            double flow = g.maxflow();
            if (flow < prev_flow-tau) {
                changed = true;
                prev_flow = flow;
                for (int j = 0; j < xout.size(); ++j) {
                    if (g.what_segment(j) ==
                            Graph<double,double,double>::SINK)
                        xout[j] = c[i];
                }
            }
        }
        if (!changed) {
            break;
        }
    }
    if (iter <= max_iters && verbose)
        std::cout << "Converged in " << iter << " iterations" << std::endl;
    int cut = 0;
    for (int i = 0; i < edges.nrow(); ++i) {
        if (xout[edges(i,0)] != xout[edges(i,1)]) { ++cut; }
    }
    List ret;
    ret["est"] = xout;
    ret["cut"] = cut;
    return ret;
}

